import java.util.ArrayList;


public class Atividade5 {

	public static void main(String[] args) {
		
		ArrayList<String> listCompra = new ArrayList<String>();

		
		/*Adicione os itens de compra: �ovos�, �leite�, �a��car�, �chocolate�, e �farinha�*/
		listCompra.add("ovos");
		listCompra.add("leite");
		listCompra.add("a��car");
		listCompra.add("chocolate");
		listCompra.add("farinha");
		
		/*Imprima os elementos da lista*/
		for (String item : listCompra) {
			System.out.println(item);
		}
		
		System.out.println("------");
		
		/*Remova o �ltimo elemento da lista e imprima a lista*/
		listCompra.remove(listCompra.size() - 1);
		for (String item : listCompra) {
			System.out.println(item);
		}
		
		System.out.println("------");
		
		/*Adicione o item �caf� no in�cio da lista e imprima a lista*/		
		listCompra.add(0, "caf�");
		for (String item : listCompra) {
			System.out.println(item);
		}
				
		System.out.println("------");
		
		/*Altere o item �a��car� para �mel� e imprima a lista*/
		int iIndexAcucar = listCompra.indexOf("a��car");
		listCompra.set(iIndexAcucar, "mel");
		for (String item : listCompra) {
			System.out.println(item);
		}
		
		System.out.println("------");
		/* Imprima a posi��o do item �leite�*/
		int iIndexleite = listCompra.indexOf("leite");
		System.out.println("Posi��o do leite:" + iIndexleite);
		
		System.out.println("------");
		/* � Ordene a lista e imprima */
		listCompra.sort(null);
		for (String item : listCompra) {
			System.out.println(item);
		}
		
	}

}
