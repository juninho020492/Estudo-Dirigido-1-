import java.util.Scanner;

public class Atividade2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner ler = new Scanner(System.in);
		int valor;

		System.out.println("Digite um numero maior que zero");
		valor = ler.nextInt();

		System.out.println("Numeros primos at� " + valor);
		for (int i = 2; i <= valor; i++) {
			if (isNumPrimo(i))
				System.out.println(i);
		}

	}

	private static boolean isNumPrimo(int numero) {
		for (int j = 2; j < numero; j++) {
			if (numero % j == 0)
				return false;
		}
		return true;
	}

}
