import java.util.Scanner;

public class Atividade1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner ler = new Scanner(System.in);
		int valor1;
		int valor2;

		System.out.println("digite o primeiro valor");
		valor1 = ler.nextInt();

		System.out.println("digite o segundo valor");
		valor2 = ler.nextInt();

		
		
		if (valor1 == valor2) {
			System.out.println("Os n�meros s�o iguais.");
		}
		else
		{
			int iMaior = Math.max(valor1, valor2);
			int iMenor = Math.min(valor1, valor2);

			System.out.println("O numero maior �: "+iMaior);
					
			System.out.println("O numero menor �: "+iMenor);		
		}

	}

}
