import java.util.Scanner;

public class Atividade3 {

	public static void main(String[] args) {

		Scanner inScan = new Scanner(System.in);
	   int iTamanho = 3;
	
		String vsPalavras[] = new String[iTamanho];

		for (int i = 0; i < vsPalavras.length; i++) {
			System.out.print("Digite a " + (i + 1) + "� palavra: ");
			vsPalavras[i] = inScan.nextLine();
		}

		
		for (int i = 0; i < iTamanho - 1; i++) {
			for (int j = 0; j < iTamanho - 1 - i; j++) {
				if (vsPalavras[j].compareTo(vsPalavras[j + 1]) > 0) {
					String sTemp = vsPalavras[j];
					vsPalavras[j] = vsPalavras[j + 1];
					vsPalavras[j + 1] = sTemp;
				}
			}
		}
		for (String sItem : vsPalavras)
			System.out.print(sItem + " ");
	}

}
