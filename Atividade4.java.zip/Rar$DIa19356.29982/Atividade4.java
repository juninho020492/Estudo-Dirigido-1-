import java.util.ArrayList;
import java.util.Scanner;

public class Atividade4 {

	public static void main(String[] args) {

		Scanner inScan = new Scanner(System.in);
		boolean bNotaValida;

		ArrayList<Aluno> listaAluno = new ArrayList<Aluno>();

		for (int i = 0; i < 3; i++) {
			Aluno aluno = new Aluno();

			System.out.println("Digite o nome do aluno " + (i + 1) + ": ");
			aluno.setNome(inScan.next());

		

			bNotaValida = false;
			while (!bNotaValida) {
				try {
					System.out.println("Digite a 1� nota do aluno " + (i + 1) + ": ");
					aluno.setNota1(inScan.nextDouble());
					bNotaValida = true;
				} catch (NotaInvalidaException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			}
			}

			

			bNotaValida = false;
			while (!bNotaValida) {
				try {
					System.out.println("Digite a 2� nota do aluno " + (i + 1) + ": ");
					aluno.setNota2(inScan.nextDouble());
					bNotaValida = true;
				} catch (NotaInvalidaException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}

			listaAluno.add(aluno);			
		}
		
		System.out.println("RESULTADOS: ");
		for (Aluno aluno : listaAluno) {

			System.out.println(aluno.getNome());
			System.out.println("M�dia: " + aluno.calcularMedia());
			System.out.println("Situa��o:" + aluno.situacao());
			System.out.println("......................");
		}

	}

}
